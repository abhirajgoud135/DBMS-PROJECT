package aptitude_analysis;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class First_frame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JMenuBar mnubar;
	JMenu m1,m2,m3,m4,m5;
	JMenuItem in1,in2,in3,in4,in5,up1,up2,up3,up4,up5,dl1,dl2,dl3,dl4,dl5;
	public First_frame() {
		mnubar=new JMenuBar();
		m1=new JMenu("Student_Details");
		m2=new JMenu("Aprtitude_Quiz_Exam");
		m3=new JMenu("Marks_scored");
		m4=new JMenu("Aptitude_quiz_marks");
		m5=new JMenu("Student_Aptitude_quiz_exam");
		in1=new JMenuItem("Insert");
		up1=new JMenuItem("Update");
		dl1=new JMenuItem("Delete");
		in2=new JMenuItem("Insert");
		up2=new JMenuItem("Update");
		dl2=new JMenuItem("Delete");
		in3=new JMenuItem("Insert");
		up3=new JMenuItem("Update");
		dl3=new JMenuItem("Delete");
		in4=new JMenuItem("Insert");
		up4=new JMenuItem("Update");
		dl4=new JMenuItem("Delete");
		in5=new JMenuItem("Insert");
		up5=new JMenuItem("Update");
		dl5=new JMenuItem("Delete");
		getContentPane().setBackground(Color.pink);
		setVisible(true);
		setSize(2000,1000);
		setTitle("Aptitude Quiz Performance Analysis");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new FlowLayout());
		setJMenuBar(mnubar);
		mnubar.add(m1);
		m1.add(in1);
		m1.add(up1);
		m1.add(dl1);
		mnubar.add(m2);
		m2.add(in2);
		m2.add(up2);
		m2.add(dl2);
		mnubar.add(m3);
		m3.add(in3);
		m3.add(up3);
		m3.add(dl3);
		mnubar.add(m4);
		m4.add(in4);
		m4.add(up4);
		m4.add(dl4);
		mnubar.add(m5);
		m5.add(in5);
		m5.add(up5);
		m5.add(dl5);
	
		in1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new insert_student_details();
			}
		});
		up1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new update_student_details();
				
			}
		});
		dl1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new delete_student_details();
				
			}
		});
		in2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new insert_aptitude_quiz_exam();
			}
		});
		up2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new update_aptitude_quiz_exam();
				
			}
		});
		dl2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new delete_aptitude_quiz_exam();
				
			}
		});
		in3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new insert_marks_scored();
				
			}
		});
		up3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new update_marks_scored();
				
			}
		});
		dl3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new delete_marks_scored();
				
			}
		});
		in4.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new insert_aptitude_quiz_marks();
				
			}
		});
		up4.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new update_aptitude_quiz_marks();
				
			}
		});
		dl4.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new delete_aptitude_quiz_marks();
				
			}
		});
		in5.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new insert_student_Aptitude_quiz_exam();
				
			}
		});
		up5.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new update_student_Aptitude_quiz_exam();
				
			}
		});
		dl5.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new delete_student_Aptitude_quiz_exam();
				
			}
		});
			
	}
	
	
	public static void main(String a[]) {
		new First_frame();
	}
	
}
