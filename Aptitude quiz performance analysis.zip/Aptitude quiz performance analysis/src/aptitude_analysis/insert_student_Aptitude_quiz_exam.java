package aptitude_analysis;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class insert_student_Aptitude_quiz_exam extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JPanel jp1,jp2,jp3;
	Connection con;
	int i;
	java.sql.Statement stmt;
	JLabel mid;
	JLabel ht;
	JLabel ed;
	JTextField m,h,e;
	TextArea ta;
	JButton in;
	
	public insert_student_Aptitude_quiz_exam()
	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL","project","vasavi");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt=con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mid=new JLabel("Mail-id");
		m=new JTextField(10);
		ht=new JLabel("Hall-ticket");
		h=new JTextField(10);
		ed=new JLabel("Exam-date");
		e=new JTextField(10);
		ta=new TextArea(20,100);
		in=new JButton("submit");
		jp1=new JPanel(new GridLayout(3,2));
		jp2=new JPanel(new FlowLayout());
		jp3=new JPanel(new FlowLayout());
		jp1.add(mid);
		jp1.add(m);
		jp1.add(ht);
		jp1.add(h);
		jp1.add(ed);
		jp1.add(e);
		jp2.add(in);
		jp3.add(ta);
		add(jp1);
		add(jp2);
		add(jp3);
		setVisible(true);
		setSize(2000,1000);
		setTitle("Enter following details:");
		setLayout(new GridLayout(3,1));
		pack();
in.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				try {
					 i=stmt.executeUpdate("insert into student_aptitude_quiz_exam values ('"+ m.getText() +"','"+h.getText()+"','"+e.getText()+"')");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				ta.append("\n Inserted "+i+"rows successfully");
			}
		});
	}

}
