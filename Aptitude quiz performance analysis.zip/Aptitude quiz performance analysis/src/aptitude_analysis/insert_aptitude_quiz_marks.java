package aptitude_analysis;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class insert_aptitude_quiz_marks extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JPanel jp1,jp2,jp3;
	Connection con;
	int i;
	java.sql.Statement stmt;
	JLabel rk;
	JLabel ht;
	JLabel si;
	JTextField r,h,s;
	TextArea ta;
	JButton in;
	/*void displaySQLErrors(SQLException e) {
		ta.append("\nSQLException:" + e.getMessage() +"\n");
		ta.append("SQLState:    "+ e.getSQLState() + "\n");
		ta.append("VendorError:  " + e.getErrorCode() + "\n");
		
	}*/
	
	public insert_aptitude_quiz_marks()
	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL","project","vasavi");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//displaySQLErrors(e);
			e.printStackTrace();
		}
		try {
			stmt=con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//displaySQLErrors(e);
			e.printStackTrace();
		}
		rk=new JLabel("Rank of the student");
		r=new JTextField(10);
		ht=new JLabel("Hall-Ticket");
		h=new JTextField(10);
		si=new JLabel("Sheet-id");
		s=new JTextField(10);
		ta=new TextArea(20,100);
		in=new JButton("submit");
		jp1=new JPanel(new FlowLayout());
		jp2=new JPanel(new FlowLayout());
		jp3=new JPanel(new FlowLayout());
		jp1.add(rk);
		jp1.add(r);
		jp1.add(ht);
		jp1.add(h);
		jp1.add(si);
		jp1.add(s);
		jp2.add(in);
		jp3.add(ta);
		add(jp1);
		add(jp2);
		add(jp3);
		setVisible(true);
		setSize(2000,1000);
		setTitle("Enter following details:");
		setLayout(new FlowLayout());
		pack();
in.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				try {
					String rank=r.getText();
					if(checkint(rank)==0) {
						JOptionPane.showMessageDialog(null, "Rank should be an Integer");
						throw new Exception();
					}
					 i=stmt.executeUpdate("insert into aptitude_quiz_marks values ("+ r.getText() +",'"+h.getText()+"','"+s.getText()+"')");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					//displaySQLErrors(e);
					e.printStackTrace();
				}
				catch(Exception e1) {
					System.out.println("e1");
				}
				ta.append("\n Inserted "+i+"rows successfully");
			}
		});
	}
	public int checkint(String rank) {
		try {
			Integer.parseInt(rank);
			return 1;
		}
		catch(Exception e) {
			return 0;
		}
		
	}
}
