package aptitude_analysis;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class insert_student_details extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JPanel jp1,jp2,jp3;
	Connection con;
	int i;
	java.sql.Statement stmt;
	JLabel mid;
	JLabel nm;
	JLabel cl;
	JTextField m,n,c;
	TextArea ta;
	JButton in;
	
	public insert_student_details()
	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL","project","vasavi");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			stmt=con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		nm=new JLabel("Name of the student");
		m=new JTextField(10);
		mid=new JLabel("Mail-id");
		n=new JTextField(10);
		cl=new JLabel("Class");
		c=new JTextField(10);
		ta=new TextArea(20,100);
		in=new JButton("submit");
		jp1=new JPanel(new FlowLayout());
		jp2=new JPanel(new FlowLayout());
		jp3=new JPanel(new FlowLayout());
		jp1.add(nm);
		jp1.add(n);
		jp1.add(mid);
		jp1.add(m);
		jp1.add(cl);
		jp1.add(c);
		jp2.add(in);
		jp3.add(ta);
		add(jp1);
		add(jp2);
		add(jp3);
		setVisible(true);
		getContentPane().setBackground(Color.pink);
		setSize(2000,1000);
		setTitle("Enter following details:");
		setLayout(new FlowLayout());
		pack();
		
		in.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				try {
					
					 i=stmt.executeUpdate("insert into student_details values ('"+ n.getText() +"','"+m.getText()+"','"+c.getText()+"')");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				ta.append("\n Inserted "+i+"rows successfully");
			}
		});

	}
}
